#define TYPE uintmax_t
#define NAME strtoumax
#include "strtox.c"
